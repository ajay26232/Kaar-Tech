const express = require('express');
const cors = require('cors');
const request = require('request');
const app = express();
const port = 3000;
var convert = require('xml-js');


//----------------------------------Used for JSON Parsing/ Handles CORS Origin Errors----------------------
app.use(express.json(), cors(
));

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  next();
});


app.listen(port, () => {
  console.log("backend is running.Now you can carry out your work AJAY.....");
})

//-------------------------------------------------Login-----------------------------------------------------
var customerID;
app.post('/login', (req, res) => {

  // getting User Name & Password from JSON request
  var username = req.body.username;
  var password = req.body.password;
  customerID = req.body.username;

  console.log('User ID: ' + username)
  console.log('Password: ' + password)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_login_aj/100/zws_login_aj/zws_login_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_LOGIN_AJ:ZCP_LOGIN_AJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_LOGIN_AJAY_FM>\r\n         <ZCUSID>' + username + '</ZCUSID>\r\n         <ZPASSWORD>' + password + '</ZPASSWORD>\r\n      </urn:ZCP_LOGIN_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var result1 = convert.xml2json(response.body, {
      compact: true,
      spaces: 10
    });
    console.log(JSON.stringify(result1));
    const result2 = JSON.parse(result1);

    console.log(result2['soap-env:Envelope']['soap-env:Body']['n0:ZCP_LOGIN_AJAY_FMResponse']['RESULT']['_text']);
    console.log(result2['soap-env:Envelope']['soap-env:Body']['n0:ZCP_LOGIN_AJAY_FMResponse']['NAME']['_text']);
    res.json({
      result: result2['soap-env:Envelope']['soap-env:Body']['n0:ZCP_LOGIN_AJAY_FMResponse']['RESULT']['_text'],
      customerName: result2['soap-env:Envelope']['soap-env:Body']['n0:ZCP_LOGIN_AJAY_FMResponse']['NAME']['_text']
    })
  })
});


//-------------------------------------------------Credit-Debit-----------------------------------------------------

app.post('/crdb', (req, res) => {

  console.log('Customer ID: ' + customerID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_credebit_rfc/100/zws_credebit_rfc/zws_credebit_rfc',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_CREDEBIT_RFC:ZCP_CREDIT_DEBT_AJAYRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_CREDIT_DEBT_AJAY>\r\n         <IM_CUSTOMER_ID>' + customerID + '</IM_CUSTOMER_ID>\r\n         <!--Optional:-->\r\n         <IT_CREDIT>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n              \r\n            </item>\r\n         </IT_CREDIT>\r\n         <!--Optional:-->\r\n         <IT_DEBIT>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n              \r\n            </item>\r\n         </IT_DEBIT>\r\n      </urn:ZCP_CREDIT_DEBT_AJAY>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//-------------------------------------------------INQUIRY-----------------------------------------------------

app.post('/inquirydata', (req, res) => {

  console.log('Customer ID: ' + customerID)
  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_inquiry_aj/100/zws_inquiry_aj/zws_inquiry_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_INQUIRY_AJ:ZCP_INQUIRY_BAJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_INQUIRY_BAJAY_FM>\r\n         <IM_CUSTOMER_ID>' + customerID + '</IM_CUSTOMER_ID>\r\n         <!--Optional:-->\r\n         <IT_INQUIRY>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n             \r\n            </item>\r\n         </IT_INQUIRY>\r\n      </urn:ZCP_INQUIRY_BAJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//-------------------------------------------------SALES ORDER-----------------------------------------------------

app.post('/salesorder', (req, res) => {



  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_saleorder_aj/100/zws_saleorder_aj/zws_saleorder_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_SALEORDER_AJ:ZCP_SALE_ORDER2_AJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_SALE_ORDER2_AJAY_FM>\r\n         <CUST_ID>' + customerID + '</CUST_ID>\r\n         <IT_INVOICE>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n            </item>\r\n         </IT_INVOICE>\r\n      </urn:ZCP_SALE_ORDER2_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});


//-------------------------------------------------LOD-----------------------------------------------------

app.post('/lod', (req, res) => {


  console.log('Customer ID: ' + customerID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_listofdelivery_aj/100/zws_listofdelivery_aj/zws_listofdelivery_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_LISTOFDELIVERY_AJ:ZCP_LOD_AJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_LOD_AJAY_FM>\r\n         <IM_CUSTOMER_ID>' + customerID + '</IM_CUSTOMER_ID>\r\n         <!--Optional:-->\r\n         <IT_LOD>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n            </item>\r\n         </IT_LOD>\r\n      </urn:ZCP_LOD_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});


//-------------------------------------------------INVOICE-----------------------------------------------------

app.post('/invoice', (req, res) => {


  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_invoice_aj/100/zws_invoice_aj/zws_invoice_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_INVOICE_AJ:ZFM_AJAY_INVOICEDETRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZFM_AJAY_INVOICEDET>\r\n         <CUST_ID>' + customerID + '</CUST_ID>\r\n         <IT_INVOICE>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n            </item>\r\n         </IT_INVOICE>\r\n      </urn:ZFM_AJAY_INVOICEDET>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});


//-------------------------------------------------PAYMENTAGING-----------------------------------------------------

app.post('/payment', (req, res) => {

  console.log('Customer ID: ' + customerID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_paymentaging_aj/100/zws_paymentaging_aj/zws_paymentaging_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_PAYMENTAGING_AJ:ZCP_PAYMENTAGING2_AJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_PAYMENTAGING2_AJAY_FM>\r\n         <CUST_ID>' + customerID + '</CUST_ID>\r\n         <IT_DET>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n            \r\n            </item>\r\n         </IT_DET>\r\n      </urn:ZCP_PAYMENTAGING2_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//-------------------------------------------------OVERALL SALE-----------------------------------------------------

app.post('/overallsales', (req, res) => {

  var customerID = 12;
  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_ovrallsale_aj/100/zws_ovrallsale_aj/zws_ovrallsale_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_OVRALLSALE_AJ:ZCP_OVERALL_SALE_AJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_OVERALL_SALE_AJAY_FM>\r\n         <IM_SALES_DOC_NUM>' + customerID + '</IM_SALES_DOC_NUM>\r\n         <!--Optional:-->\r\n         <RESULT>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n           \r\n            </item>\r\n         </RESULT>\r\n      </urn:ZCP_OVERALL_SALE_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//-------------------------------------------------PROFILE-----------------------------------------------------

app.post('/profilepage', (req, res) => {

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zws_profile_aj/100/zws_profile_aj/zws_profile_aj',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZWS_PROFILE_AJ:ZCP_PROFILE_AJAY_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZCP_PROFILE_AJAY_FM>\r\n         <ZCUSID>' + customerID + '</ZCUSID>\r\n      </urn:ZCP_PROFILE_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});
//---------------------------------------------------CustomerinvoicePDF-------------------------------------------------//

//-------------------------------------------------Invoice PDF-----------------------------------------------------



app.post('/invoicefrm', (req, res) => {

  // var CustomerID = 9;
  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxbktlds4.kaarcloud.com:8000/sap/bc/srt/rfc/sap/zsd_custinvoicepdf3_ajay_fm/100/zsn_custinvoicepdf3_ajay_fm/zsn_custinvoicepdf3_ajay_fm',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'urn:sap-com:document:sap:rfc:functions:ZSD_CUSTINVOICEPDF3__FM:ZFM_AJAY_INVOICE2FORMPDF_FMRequest',
      'Authorization': 'Basic QWJhcGVyOkFiYXBlckAxMjM=',
      'Cookie': 'sap-usercontext=sap-client=100'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZFM_AJ_INVOICE2FORMPDF_FM>\r\n         <CUST_ID>'+customerID+'</CUST_ID>\r\n      </urn:ZFM_AJ_INVOICE2FORMPDF_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {

    if (error) throw new Error(error);
    var xmljs = convert.xml2js(response.body, {
      compact: true,

      spaces: 10

    });
    xmljs = xmljs["soap-env:Envelope"]["soap-env:Body"]["n0:ZFM_AJ_INVOICE2FORMPDF_FMResponse"]["IT_RESULT"]["_text"]

    xmljs = JSON.stringify(xmljs)

    res.send(xmljs);

    console.log(xmljs);

  })

});
//----------------------------------------------VENDOR PORTAL-----------------------------------------------------------------//
//----------------------------------------------VENDOR LOGIN------------------------------------------------------------------//
var VendorID;
app.post('/venlogin', (req, res) => {

  // getting User Name & Password from JSON request
  var username = req.body.username;
  var password = req.body.password;
  VendorID = req.body.username;

  console.log('User ID: ' + username)
  console.log('Password: ' + password)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_VENDORLOGINAJAY&receiverParty=&receiverService=&interface=SI_AJAY_VENLOGIN&interfaceNamespace=http://vendorportalajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_LOGIN_AJAY_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <IM_PASSWORD>' + password + '</IM_PASSWORD>\r\n         <IM_VENDOR_ID>' + username + '</IM_VENDOR_ID>\r\n      </urn:ZVP_LOGIN_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var result1 = convert.xml2json(response.body, {
      compact: true,
      spaces: 10
    });
    const result2 = JSON.parse(result1);

    console.log(result2['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_LOGIN_AJAY_FM.Response']['EX_VALUE']['_text']);

    res.json({
      result: result2['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_LOGIN_AJAY_FM.Response']['EX_VALUE']['_text'],
    })
  })
});

//------------------------------------------------------VENDOR PROFILE VIEW-----------------------------------------------------//

app.post('/venprofile', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_VENPROFILEAJAY&receiverParty=&receiverService=&interface=SI_VENDORPROFILE&interfaceNamespace=http://vendorprofileajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_PROFILE_AJAY_FM>\r\n         <IM_VENDOR_ID>' + VendorID + '</IM_VENDOR_ID>\r\n      </urn:ZVP_PROFILE_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});
//-------------------------------------------------VENDOR REQUEST FOR QUOTATION-------------------------------------------------//
app.post('/venrequest', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_VENDOREQUOTATION&receiverParty=&receiverService=&interface=SI_VENDORREQUOATIONAJAY&interfaceNamespace=http://vendorReQuotationajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_QUOTATION_AJ_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <VENDOR_ACC>' + VendorID + '</VENDOR_ACC>\r\n         <!--Optional:-->\r\n         <IT_RFQ_LIST>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n    \r\n            </item>\r\n         </IT_RFQ_LIST>\r\n      </urn:ZVP_QUOTATION_AJ_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});
//-------------------------------------------------------VENDOR PURCHASE ORDER--------------------------------------------------//
app.post('/venpurchase', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_PURCHASEOORDERAJAY&receiverParty=&receiverService=&interface=SI_PURCHASEORDER&interfaceNamespace=http://vendorpurchaseorderajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_PURCHASE_ORD_AJAY_FM>\r\n         <!--You may enter the following 3 items in any order-->\r\n         <IM_VENDOR_ID>' + VendorID + '</IM_VENDOR_ID>\r\n         <!--Optional:-->\r\n         <IT_PURCHASE_ORDER_HEADER>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n             \r\n            </item>\r\n         </IT_PURCHASE_ORDER_HEADER>\r\n         <!--Optional:-->\r\n         <IT_PURCHASE_ORDER_ITEMS>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               <!--Optional:-->\r\n          \r\n            </item>\r\n         </IT_PURCHASE_ORDER_ITEMS>\r\n      </urn:ZVP_PURCHASE_ORD_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});
//----------------------------------------------VENDOR GOODS RECEIPT------------------------------------------------------------//
app.post('/venreceipt', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_GOODRECEIPT&receiverParty=&receiverService=&interface=SI_GOODRECIEPTAJAY&interfaceNamespace=http://vendorgoodsrecieptajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_GOODSRECEIPT_AJAY_FM>\r\n         <!--You may enter the following 3 items in any order-->\r\n         <IM_VENDOR_ID>' + VendorID + '</IM_VENDOR_ID>\r\n         <!--Optional:-->\r\n         <IT_GOODS_HEADER>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n             \r\n            </item>\r\n         </IT_GOODS_HEADER>\r\n         <!--Optional:-->\r\n         <IT_RETURN>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n             \r\n            </item>\r\n         </IT_RETURN>\r\n      </urn:ZVP_GOODSRECEIPT_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//------------------------------------------------VENDOR INVOICE DETAILS--------------------------------------------------------//
app.post('/veninvoice', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_VEPINVOICEAJAY&receiverParty=&receiverService=&interface=SI_VEINVOICEAJAY&interfaceNamespace=http://veinvoiceajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyNDA2MTUFAAQAAAAICgAIUE9VU0VSQDP%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzI0MDYxNTQwWjAjBgkqhkiG9w0BCQQxFgQUrm%2FqhliTRTPowJJdBi2awp%2FHircwCQYHKoZIzjgEAwQuMCwCFFHIbGJjbowhsBLoZI5W5amLwmHrAhQ!wstft2IgKq!SJLRD82KgHpNmBA%3D%3D; JSESSIONID=c2R8O7ga_Lhx-8MytigGn5xRCYqGiQF-Y2kA_SAPenQORWS-HbP83oqe1MhD6F5Q; JSESSIONMARKID=cMbmDw_solKygEcHtQJtKs9CipYKpNCgYgB35jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:Z_VENDOR_INVOICE_AJAY>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <VENDOR_ID>' + VendorID + '</VENDOR_ID>\r\n         <IT_INVOICE>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               \r\n            </item>\r\n         </IT_INVOICE>\r\n      </urn:Z_VENDOR_INVOICE_AJAY>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//---------------------------------------------VENDOR INVOICE-PDF---------------------------------------------------------------//
//-------------------------------------------------Vendor-Invoice PDF-----------------------------------------------------

app.post('/veninvoicepdf', (req, res) => {

  // var VendorID = 6;
  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=A1_BC1_AJAYVENDOR_PORTALS&receiverParty=&receiverService=&interface=SD_AJAY_VEN_INOVICEPDF1&interfaceNamespace=http://narmadhaven.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcxMTA4MjYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzExMDgyNjE1WjAjBgkqhkiG9w0BCQQxFgQUF8GxMbdIFK%2FtWkfr77GA0vtoRJkwCQYHKoZIzjgEAwQvMC0CFQDjrax1!crtYiaklYrvr5MQfG7VzQIUc8hUZLhdhBZQOZuiUsbvs!cLjns%3D; JSESSIONID=25Y1qbNYr6GgdK_PIUt2ptxPJhBEiQF-Y2kA_SAPTmbbMyDlK31gu25papCEN0x5; JSESSIONMARKID=Ow-hIAbI03d-URnuKgVwFB9_MGrbTOlp-CDn5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_INVOICE_FORM>\r\n         <VEN_ID>' + VendorID + '</VEN_ID>\r\n      </urn:ZVP_INVOICE_FORM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {

    if (error) throw new Error(error);
    var xmljs = convert.xml2js(response.body, {
      compact: true,

      spaces: 10

    });
    xmjs = xmljs["SOAP:Envelope"]["SOAP:Body"]["ns0:ZVP_INVOICE_FORM.Response"]["RESULT"]["_text"];

    xmljs = JSON.stringify(xmjs)

    res.send(xmljs);

    console.log(xmljs);

  })

});
//----------------------------------------------VENDOR PAYMENTS AND AGING-------------------------------------------------------//
app.post('/venpayment', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_VENPAYMENTAJ&receiverParty=&receiverService=&interface=SI_VENDORPAYMENTAJAY&interfaceNamespace=http://vendorpaymentajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_PAYMENTAGING_AJAY_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <IM_VENDOR_ID>' + VendorID + '</IM_VENDOR_ID>\r\n         <!--Optional:-->\r\n         <IT_PAYMENT_AGING>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               <!--Optional:-->\r\n               \r\n            </item>\r\n         </IT_PAYMENT_AGING>\r\n      </urn:ZVP_PAYMENTAGING_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});
//-----------------------------------------------------VENDOR CREDIT DEBIT MEMO-------------------------------------------------//
app.post('/vencreditdebit', (req, res) => {

  console.log('VendorID: ' + VendorID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_CREDDEBIT&receiverParty=&receiverService=&interface=SI_CREDDEBITAJAY&interfaceNamespace=http://vendorcreditdebitajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZVP_CREDIT_DEBIT_AJAY_FM>\r\n         <!--You may enter the following 3 items in any order-->\r\n         <IM_VENDOR_ID>' + VendorID + '</IM_VENDOR_ID>\r\n         <!--Optional:-->\r\n         <IT_CREDIT_MEMO>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n \r\n            </item>\r\n         </IT_CREDIT_MEMO>\r\n         <!--Optional:-->\r\n         <IT_DEBIT_MEMO>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               \r\n            </item>\r\n         </IT_DEBIT_MEMO>\r\n      </urn:ZVP_CREDIT_DEBIT_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});


//-------------------------------------------------EMPLOYEE PORTAL----------------------------------------------------------------
//--------------------------------------------------LOGIN----------------------------------------------------------------------//
var EmployeeID;
app.post('/emplogin', (req, res) => {

  // getting User Name & Password from JSON request
  var username = req.body.username;
  var password = req.body.password;
  EmployeeID = req.body.username;

  console.log('User ID: ' + username)
  console.log('Password: ' + password)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_EMPPORTALOGINAJAY&receiverParty=&receiverService=&interface=SI_EMPORTALLOGINAJAY&interfaceNamespace=http://emportalloginajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_LOGIN_AJAY_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <IM_EMPLOYEE_ID>' + username + '</IM_EMPLOYEE_ID>\r\n         <IM_PASSWORD>' + password + '</IM_PASSWORD>\r\n      </urn:ZEP_LOGIN_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var result1 = convert.xml2json(response.body, {
      compact: true,
      spaces: 10
    });
    const result2 = JSON.parse(result1);

    console.log(result2['SOAP:Envelope']['SOAP:Body']['ns0:ZEP_LOGIN_AJAY_FM.Response']['EX_STATUS']['_text']);

    res.json({
      result: result2['SOAP:Envelope']['SOAP:Body']['ns0:ZEP_LOGIN_AJAY_FM.Response']['EX_STATUS']['_text'],
    })
  })
});

//-------------------------------------------------Employee Dashboard - Employee Profile View-----------------------------------------------------

app.post('/emprofile', (req, res) => {

  console.log('EmployeeID: ' + EmployeeID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_AJEPROFILE&receiverParty=&receiverService=&interface=SI_AJEPROFILE&interfaceNamespace=http://ajeprofile.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyNDE2NDUFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzI0MTY0NTQ4WjAjBgkqhkiG9w0BCQQxFgQU8444qr1wfSI1LWrT9G5Th6gFEWcwCQYHKoZIzjgEAwQvMC0CFQDn4tUvpwtG8LBH3vwMMqOncFig7gIUBLwVox0Mu6!DqhkaRmFLF2Mn6V8%3D; JSESSIONID=4nNUILb4nO3VjagvYd1D2mwq8cqIiQF-Y2kA_SAPR8qRH5GBeBPW101IcTfX5j8P; JSESSIONMARKID=r3Ay9At5mELwwCRs_dTd_fd4KJiBYiy-eCKX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_PROFILE_FM_AJAY>\r\n         <IM_EMPLOYEE_ID>' + EmployeeID + '</IM_EMPLOYEE_ID>\r\n      </urn:ZEP_PROFILE_FM_AJAY>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});
//-------------------------------------------------Leave data-----------------------------------------------------

app.post('/empleave', (req, res) => {

  console.log('EmployeeID: ' + EmployeeID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_EMPLEAVEAJAY&receiverParty=&receiverService=&interface=SI_EMPLEAVEAJAY&interfaceNamespace=http://empleaveajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=7xKRFwjeW-FFyeWjWnSkDOyGY9jWqek53mBX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_LEAVE_AJAY_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <IM_EMPLOYEE_ID>' + EmployeeID + '</IM_EMPLOYEE_ID>\r\n         <!--Optional:-->\r\n         <IT_LEAVE_DATA>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               <!--Optional:-->\r\n           \r\n            </item>\r\n         </IT_LEAVE_DATA>\r\n      </urn:ZEP_LEAVE_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//----------------------------------------------------EMPLOYEE PROFILE----------------------------------------------------------//
app.post('/emprofile', (req, res) => {

  console.log('EmployeeID: ' + EmployeeID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_AJAYEMPROFILE&receiverParty=&receiverService=&interface=SI_AJAYEMPROFILE&interfaceNamespace=http://ajayemprofile.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=hSQB_gAwvjyDckEcHpijvKanTXRpN1VLm3FX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_PROFILE_AJAY_FM>\r\n         <IM_EMPLOYEE_ID>' + EmployeeID + '</IM_EMPLOYEE_ID>\r\n      </urn:ZEP_PROFILE_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//--------------------------------------------------EMPLOYEE PAYSLIP------------------------------------------------------------//

app.post('/empayslip', (req, res) => {

  console.log('EmployeeID: ' + EmployeeID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_EMLPAYSLIPAJAY&receiverParty=&receiverService=&interface=SI_EMLPAYSLIPAJAY&interfaceNamespace=http://emlpayslipajay.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDcyMzA0NTYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNzIzMDQ1NjIzWjAjBgkqhkiG9w0BCQQxFgQUOEc11ozyFBdGO6EaiODZtikQDXYwCQYHKoZIzjgEAwQvMC0CFQC%2Fpli6k0HmvxjgF4pngRjLS%2Fr3fgIUfyrtWNU!%2FayIGagqKcjN7v4KYjc%3D; JSESSIONID=0HDoKmaqYDLPjl1zfe04_O4hrSuBiQF-Y2kA_SAPFhCHuba1E0YBL1tShUC_fZly; JSESSIONMARKID=hSQB_gAwvjyDckEcHpijvKanTXRpN1VLm3FX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_PAYSLIP_AJAY_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <IM_EMPLOYEE_ID>' + EmployeeID + '</IM_EMPLOYEE_ID>\r\n         <!--Optional:-->\r\n         <IT_PAYSLIP>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               <!--Optional:-->\r\n          \r\n            </item>\r\n         </IT_PAYSLIP>\r\n      </urn:ZEP_PAYSLIP_AJAY_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);
    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//---------------------------------------------------EMPLOYEE LEAVE---------------------------------------------------------//

app.post('/emp-leave', (req, res) => {

  var EmployeeID = 8;
  console.log('EmployeeID: ' + EmployeeID)

  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=A1_BC_NARU_EMPLOYEE_PORTALS&receiverParty=&receiverService=&interface=SI_LEAVE_NARU_EMP&interfaceNamespace=http://narmadhademo.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic cG91c2VyQDM6MjAyMkBUZWNo',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDOIAAdkZWZhdWx0AQAIUE9VU0VSQDMCAAMwMDADAANLUE8EAAwyMDIzMDYyMTA4MzYFAAQAAAAICgAIUE9VU0VSQDP%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwNjIxMDgzNjM1WjAjBgkqhkiG9w0BCQQxFgQUY2Wvds9UAvPZXWp8oPH1aDwa6BAwCQYHKoZIzjgEAwQvMC0CFQC623owXPG5XqimBAhpwzgqB9zriAIUZ9azGaLutsQrvEY1yQ3Be7LSn7c%3D; JSESSIONID=OAqKY1bbzSb6n5MHcUuiOWQPLyvdiAF-Y2kA_SAPlboddeF9vSiWjX2lK_wJ7ZS7; JSESSIONMARKID=UTNHUAu-UZh9iYohbTvrCURSou8pVVh6IwEX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_LEAVE_NARU_FM>\r\n         <!--You may enter the following 2 items in any order-->\r\n         <IM_EMPLOYEE_ID>' + EmployeeID + '</IM_EMPLOYEE_ID>\r\n         <!--Optional:-->\r\n         <IT_LEAVE_DATA>\r\n            <!--Zero or more repetitions:-->\r\n            <item>\r\n               \r\n            </item>\r\n         </IT_LEAVE_DATA>\r\n      </urn:ZEP_LEAVE_NARU_FM>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);

    var xmljs = convert.xml2js(response.body, {
      compact: true,
      spaces: 10
    });

    xmljs = JSON.stringify(xmljs)
    res.send(xmljs);
    console.log(xmljs);
  })
});

//-------------------------------------------------EMPLOYEE PAYSLIP PDF---------------------------------------------------------//

app.post('/payslippdf', (req, res) => {


  var request = require('request');
  var options = {
    'method': 'POST',
    'url': 'http://dxktpipo.kaarcloud.com:50000/XISOAPAdapter/MessageServlet?senderParty=&senderService=BC_AJAY_EMP_PAYSLIPFORM&receiverParty=&receiverService=&interface=SI_ajay_EMP_PAYSLIPFORM&interfaceNamespace=http://ajayemp.com',
    'headers': {
      'Content-Type': 'text/xml;charset=UTF-8',
      'SOAPAction': 'http://sap.com/xi/WebService/soap1.1',
      'Authorization': 'Basic UE9VU0VSQDM6VGVjaEAyMDIy',
      'Cookie': 'MYSAPSSO2=AjExMDAgAA9wb3J0YWw6cG91c2VyQDSIAAdkZWZhdWx0AQAIUE9VU0VSQDQCAAMwMDADAANLUE8EAAwyMDIzMDgxNTExMDkFAAQAAAAICgAIUE9VU0VSQDT%2FAQUwggEBBgkqhkiG9w0BBwKggfMwgfACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGB0DCBzQIBATAiMB0xDDAKBgNVBAMTA0tQTzENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjMwODE1MTEwOTU1WjAjBgkqhkiG9w0BCQQxFgQUDnE2k2CUs5Ew!VUjR4M32qAhLsUwCQYHKoZIzjgEAwQvMC0CFQDIKTRJEc2HrIVhTz0ILcYosrXZGAIUEsxvrlJp2AbTQTMPJ2%2FID77AnQY%3D; JSESSIONID=uT7Dggb0snJCBpiCnKRuKZ-tVeP4iQF-Y2kA_SAPVBIT4YJ80-Ndn7Dmgjhvr5Le; JSESSIONMARKID=mAF9EA8Asbb6AmjLgTvFup5IXiOfjpW3rbyX5jaQA; saplb_*=(J2EE6906720)6906750'
    },
    body: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <urn:ZEP_PAYSLIPFORM_FM_MSP1>\r\n         <EMP_ID>' + EmployeeID + '</EMP_ID>\r\n      </urn:ZEP_PAYSLIPFORM_FM_MSP1>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>'

  };
  request(options, function (error, response) {

    if (error) throw new Error(error);
    var xmljs = convert.xml2js(response.body, {
      compact: true,

      spaces: 10

    });
    xmjs = xmljs["SOAP:Envelope"]["SOAP:Body"]["ns0:ZEP_PAYSLIPFORM_FM_ajay1.Response"]["RESULT"]["_text"];

    xmljs = JSON.stringify(xmjs)

    res.send(xmljs);

    console.log(xmljs);

  })

});