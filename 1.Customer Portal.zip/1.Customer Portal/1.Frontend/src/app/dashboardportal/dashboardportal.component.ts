import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboardportal',
  templateUrl: './dashboardportal.component.html',
  styleUrls: ['./dashboardportal.component.css']
})
export class DashboardportalComponent {
  INQUIRYDATA(){
    this.router.navigate(['./inquirydata']);
  }
  salesorder(){
    this.router.navigate(['./salesorder']);
  }
  listofdelivery(){
    this.router.navigate(['./listofdelivery']);
  }
  constructor( private router:Router,){
   
  }

}
