import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-creditdebit',
  templateUrl: './creditdebit.component.html',
  styleUrls: ['./creditdebit.component.css'],
})
export class CreditdebitComponent implements OnInit {
  Credits: any;
  Debits: any;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.http.post('http://localhost:3000/crdb', '{}').subscribe((resp: any) => {
      this.Credits =
        resp?.['soap-env:Envelope']?.['soap-env:Body']?.['n0:ZCP_CREDIT_DEBT_AJAYResponse']?.['IT_CREDIT']?.['item'];
      this.Debits =
        resp?.['soap-env:Envelope']?.['soap-env:Body']?.['n0:ZCP_CREDIT_DEBT_AJAYResponse']?.['IT_DEBIT']?.['item'];

      console.log(this.Credits);
      console.log(this.Debits);
      this.Credits.shift();
      this.Debits.shift();
    });
  }
}

