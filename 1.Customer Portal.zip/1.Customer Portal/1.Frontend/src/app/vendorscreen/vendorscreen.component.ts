import { Component } from '@angular/core';

@Component({
  selector: 'app-vendorscreen',
  templateUrl: './vendorscreen.component.html',
  styleUrls: ['./vendorscreen.component.css']
})
export class VendorscreenComponent {

}
