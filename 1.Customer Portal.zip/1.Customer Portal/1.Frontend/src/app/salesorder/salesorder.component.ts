import { Component, OnInit } from '@angular/core';
import { HttpClient, } from '@angular/common/http';


@Component({
  selector: 'app-saleorderdata',
  templateUrl: './salesorder.component.html',
  styleUrls: ['./salesorder.component.css']
})
export class SalesorderComponent implements OnInit {

  constructor(private http: HttpClient) { }

  Salesorders: any;
  arrayLength: any;


  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }
  ngOnInit(): void {

    this.http.post("http://localhost:3000/salesorder", "{}").subscribe((resp: any) => {

      this.Salesorders = resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_SALE_ORDER2_AJAY_FMResponse']['IT_INVOICE']['item'];
      this.arrayLength = this.Salesorders.length
      console.log(this.Salesorders)


    });



  }

}
