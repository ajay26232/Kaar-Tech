import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css'],
})
export class InvoiceDetailsComponent implements OnInit {
  tile: any;

  constructor(private http: HttpClient) { }

  Invoice: any;
  arrayLength: any;
  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  pdf:any;




  ngOnInit(): void {

    this.http.post("http://localhost:3000/invoice", "{}").subscribe((resp: any) => {

      this.Invoice = resp['soap-env:Envelope']['soap-env:Body']['n0:ZFM_AJAY_INVOICEDETResponse']['IT_INVOICE']['item'];
      this.arrayLength = this.Invoice.length
      console.log(this.Invoice)

    });

  }
  INVOICE_FORM(): void {
    this.http.post("http://localhost:3000/invoicefrm", "{}").subscribe((resp: any) => {

    console.log(resp)
    const linkSource = 'data:application/pdf;base64,' + resp;

    const downloadLink = document.createElement('a');

    var filename = 'Customer' + '-' + 'Invoice';

    downloadLink.href = linkSource;

    downloadLink.download = filename;

    downloadLink.click();


  }, (error) => { console.log(error) });
  }

  INVOICE_MAIL(): void {
    this.http.post("http://localhost:3000/invoicefrm", "{}").subscribe((resp: any) => {

    console.log(resp)
    const byteArray = new Uint8Array(

      atob(resp)

        .split('')

        .map((char) => char.charCodeAt(0))

    );

    const blob = new Blob([byteArray], { type: 'application/pdf' });

    const blobUrl = URL.createObjectURL(blob);

    window.open(`mailto:test@example.com?subject=subject&body=${blobUrl}`);


  }, (error) => { console.log(error) });
  }

  INVOICE_PRINT(): void {
    this.http.post("http://localhost:3000/invoicefrm", "{}").subscribe((resp: any) => {

    console.log(resp)
    const byteArray = new Uint8Array(

      atob(resp)

        .split('')

        .map((char) => char.charCodeAt(0))

    );

    const blob = new Blob([byteArray], { type: 'application/pdf' });

    const blobUrl = URL.createObjectURL(blob);

    const iframe: any = document.createElement('iframe');

    iframe.style.display = 'none';

    iframe.src = blobUrl;

    document.body.appendChild(iframe);

    iframe.contentWindow.print();


  }, (error) => { console.log(error) });
  }


  }
