import { Component } from '@angular/core';

@Component({
  selector: 'app-vendashboard',
  templateUrl: './vendashboard.component.html',
  styleUrls: ['./vendashboard.component.css']
})
export class VendashboardComponent {

}
