import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-empayslip',
  templateUrl: './empayslip.component.html',
  styleUrls: ['./empayslip.component.css']
})
export class EmpayslipComponent {

  constructor(private http: HttpClient) { }

  payslipdatum: any;
  arrayLength: any;
  value: any;

  searchText: any;
  leavedatum: any;


  quotationdata: any;
  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }

  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }


  ngOnInit(): void {

    this.http.post("http://localhost:3000/empayslip", "{}").subscribe((resp: any) => {

      this.payslipdatum = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZEP_PAYSLIP_AJAY_FM.Response']['IT_PAYSLIP']['item'];
      this.arrayLength = this.payslipdatum.length

      console.log(this.payslipdatum)


    });





  }
EMPPAYSLIP_FORM(): void {

  this.http.post("http://localhost:3000/payslippdf", "{}").subscribe((resp: any) => {



    console.log(resp)

    const linkSource = 'data:application/pdf;base64,' + resp;



    const downloadLink = document.createElement('a');



    var filename = 'EMPLOYEE' + '-' + 'PAYSLIP';



    downloadLink.href = linkSource;



    downloadLink.download = filename;



    downloadLink.click();





  }, (error) => { console.log(error) });

}

EMPPAYSLIP_PRINT(): void {

  this.http.post("http://localhost:3000/payslippdf", "{}").subscribe((resp: any) => {



    console.log(resp)

    const linkSource = 'data:application/pdf;base64,' + resp;



    const downloadLink = document.createElement('a');



    var filename = 'EMPLOYEE' + '-' + 'PAYSLIP';



    downloadLink.href = linkSource;



    downloadLink.download = filename;



    downloadLink.click();





  }, (error) => { console.log(error) });

}



EMPPAYSLIP_MAIL(): void {

  this.http.post("http://localhost:3000/payslippdf", "{}").subscribe((resp: any) => {



    console.log(resp)

    const byteArray = new Uint8Array(



      atob(resp)



        .split('')



        .map((char) => char.charCodeAt(0))



    );



    const blob = new Blob([byteArray], { type: 'application/pdf' });



    const blobUrl = URL.createObjectURL(blob);



    window.open(`mailto:test@example.com?subject=subject&body=${blobUrl}`);





  }, (error) => { console.log(error) });

}


}

