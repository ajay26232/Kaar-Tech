import { Component } from '@angular/core';

@Component({
  selector: 'app-vendorfinance',
  templateUrl: './vendorfinance.component.html',
  styleUrls: ['./vendorfinance.component.css']
})
export class VendorfinanceComponent {

}
