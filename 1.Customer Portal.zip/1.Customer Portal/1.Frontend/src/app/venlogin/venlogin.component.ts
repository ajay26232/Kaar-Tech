import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl,Validators,FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppServiceService } from '../app-service.service';

@Component({
  selector: 'app-venlogin',
  templateUrl: './venlogin.component.html',
  styleUrls: ['./venlogin.component.css']
})
export class VenloginComponent {
  private url = 'http://localhost:3000/venlogin';

  public showPassword: boolean = false;
 form = new FormGroup({
   username: new FormControl('', [Validators.required]),
   password: new FormControl('', [Validators.required]),
 });
password: any;
username: any;

 get loginData(){
  return this.form.controls;
 }

 value = true;
 constructor( private router:Router,private http: HttpClient,private service:AppServiceService){

 }

 Onsubmit(){
   // console.log (this.form.value);
   console.log (JSON.stringify(this.form.value));
   //  this.router.navigate(['./dashboard']);
   const headers = new HttpHeaders().set('Authorization', 'my-auth-token') .set('Content-Type', 'application/json');
   this.http.post(this.url, JSON.stringify(this.form.value), { headers: headers }).subscribe((data: any) =>
   // this.service.getdata().subscribe((data: any) =>
    {
    const check = data.result;
    console.log('Backend Response: '+check);
    if(check=='LOGIN SUCCESS!!'){ this.router.navigate(['venscreen']) }
    else{ alert("Login Failed! Please check the User ID and Password Combination.") } });
 }


  public togglePasswordVisibility(): void {
   this.showPassword = !this.showPassword;
 }

}
