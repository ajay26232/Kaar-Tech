import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
})
export class PaymentComponent {
  constructor(private http: HttpClient) {}

  Payages: any;
  arrayLength: any;
  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }

  ngOnInit(): void {
    this.http.post("http://localhost:3000/payment", "{}").subscribe((resp: any) => {

    this.Payages = resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_PAYMENTAGING2_AJAY_FMResponse']['IT_DET']['item'];
    this.arrayLength = this.Payages.length
    console.log(this.Payages)


  });
  }
}
