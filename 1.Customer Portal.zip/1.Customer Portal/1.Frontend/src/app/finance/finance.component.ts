import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-finance',
  templateUrl: './finance.component.html',
  styleUrls: ['./finance.component.css']
})
export class FinanceComponent {
  read(){
    this.router.navigate(['./dashboardportal']);
    } 
    constructor( private router:Router){
   
    }

    creditDebit(){
      
    }

  

}
