import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { InquirydataComponent } from './inquirydata/inquirydata.component';
import { CustomerportalComponent } from './customerportal/customerportal.component';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { DashboardportalComponent } from './dashboardportal/dashboardportal.component';
import { SalesorderComponent } from './salesorder/salesorder.component';
import { ListofdeliveryComponent } from './listofdelivery/listofdelivery.component';
import { ProfilepageComponent } from './profilepage/profilepage.component';
import { FinanceportalComponent } from './financeportal/financeportal.component';
import { CreditdebitComponent } from './creditdebit/creditdebit.component';
import { OverallsalesComponent } from './overallsales/overallsales.component';
import { InvoiceDetailsComponent } from './invoice/invoice.component';
import { PaymentComponent } from './payment/payment.component';
import { OpeningpageComponent } from './openingpage/openingpage.component';
import { VenloginComponent } from './venlogin/venlogin.component';
import { VendorscreenComponent } from './vendorscreen/vendorscreen.component';
import { VendashboardComponent } from './vendashboard/vendashboard.component';
import { VendorfinanceComponent } from './vendorfinance/vendorfinance.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { EmpdashboardComponent } from './empdashboard/empdashboard.component';
import { VenRequotationComponent } from './ven-requotation/ven-requotation.component';
import { VencreditdebitComponent } from './vencreditdebit/vencreditdebit.component';
import { VengoodreceiptComponent } from './vengoodreceipt/vengoodreceipt.component';
import { VenpaymentagingComponent } from './venpaymentaging/venpaymentaging.component';
import { VeninvoiceComponent } from './veninvoice/veninvoice.component';
import { VenprofileComponent } from './venprofile/venprofile.component';
import { VenpurchaseorderComponent } from './venpurchaseorder/venpurchaseorder.component';
import { EmprofileComponent } from './emprofile/emprofile.component';
import { EmpleaveComponent } from './empleave/empleave.component';
import { EmpayslipComponent } from './empayslip/empayslip.component';
import { CustdashboardComponent } from './custdashboard/custdashboard.component';


const routes: Routes = [
   {path:'', component:OpeningpageComponent},
   {path:'login', component:LoginComponent},
   {path:'crdb', component:CreditdebitComponent},
   {path:'inquirydata', component:InquirydataComponent},
   {path:'customerportal',component:CustomerportalComponent},
   {path:'dashboardportal',component:DashboardportalComponent},
   {path:'salesorder',component:SalesorderComponent},
   {path:'listofdelivery',component:ListofdeliveryComponent},
   {path:'profilepage',component:ProfilepageComponent},
   {path:'financeportal',component:FinanceportalComponent},
   {path:'overallsales',component:OverallsalesComponent},
   {path:'invoice',component:InvoiceDetailsComponent},
   {path:'payment',component:PaymentComponent},
   {path:'opage',component:OpeningpageComponent},
   {path:'venlogin',component:VenloginComponent},
   {path:'venscreen',component:VendorscreenComponent},
   {path:'vendashboard',component:VendashboardComponent},
   {path:'venfinance',component:VendorfinanceComponent},
   {path:'emplogin',component:EmploginComponent},
   {path:'empdashboard',component:EmpdashboardComponent},
   {path:'venrequest',component:VenRequotationComponent},
   {path:'vencreditdebit',component:VencreditdebitComponent},
   {path:'venpurchase',component:VenpurchaseorderComponent},
   {path:'veninvoice',component:VeninvoiceComponent},
   {path:'venpayment',component:VenpaymentagingComponent},
   {path:'venprofile',component:VenprofileComponent},
   {path:'venreceipt',component:VengoodreceiptComponent},
   {path:'empayslip',component:EmpayslipComponent},
   {path:'empleave',component:EmpleaveComponent},
   {path:'emprofile',component:EmprofileComponent},
   {path:'custdashboard',component:CustdashboardComponent},




];

@NgModule({
  imports: [RouterModule.forRoot(routes),CommonModule,BrowserModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
