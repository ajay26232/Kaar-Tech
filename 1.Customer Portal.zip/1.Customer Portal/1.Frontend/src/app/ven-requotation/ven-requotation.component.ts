import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-ven-requotation',
  templateUrl: './ven-requotation.component.html',
  styleUrls: ['./ven-requotation.component.css']
})
export class VenRequotationComponent {

  tile: any;
  login: any;
  searchText: any;
  value = 'Clear me'



  constructor(private http: HttpClient) { }

  quotationdata: any;
  arrayLength: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }
  ngOnInit(): void {

    this.http.post("http://localhost:3000/venrequest", "{}").subscribe((resp: any) => {

      this.quotationdata = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_QUOTATION_AJ_FM.Response']['IT_RFQ_LIST']['item'];
      this.arrayLength = this.quotationdata.length
      console.log(this.quotationdata)
      this.quotationdata.shift();


    });
  }


}
