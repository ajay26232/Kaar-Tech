import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  templateUrl: './profilepage.component.html',
  styleUrls: ['./profilepage.component.css']
})
export class ProfilepageComponent {
  constructor(private http: HttpClient) { }

  Profiles: any;


  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  ngOnInit(): void {

    this.http.post("http://localhost:3000/profilepage", "{}").subscribe((resp: any) => {

      this.Profiles = resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_PROFILE_AJAY_FMResponse']['CUST_DATA'];

      console.log(this.Profiles)


    });




  }

}
