import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-venprofile',
  templateUrl: './venprofile.component.html',
  styleUrls: ['./venprofile.component.css']
})
export class VenprofileComponent {


  constructor(private http: HttpClient) { }

  Profiles: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }

  ngOnInit(): void {

    this.http.post("http://localhost:3000/venprofile", "{}").subscribe((resp: any) => {

      this.Profiles = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_PROFILE_AJAY_FM.Response']['EX_VENDOR_PROFILE'];

      console.log(this.Profiles)



    });
  }
}
