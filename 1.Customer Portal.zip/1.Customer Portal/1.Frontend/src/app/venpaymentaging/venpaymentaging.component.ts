import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-venpaymentaging',
  templateUrl: './venpaymentaging.component.html',
  styleUrls: ['./venpaymentaging.component.css']
})
export class VenpaymentagingComponent {

  tile: any;
  login: any;
  searchText:any;
  value = 'Clear me'
  constructor(private http: HttpClient) { }

  Payagedata: any;
  arrayLength: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }

  ngOnInit(): void {

    this.http.post("http://localhost:3000/venpayment", "{}").subscribe((resp: any) => {

      this.Payagedata = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_PAYMENTAGING_AJAY_FM.Response']['IT_PAYMENT_AGING']['item'];
      this.arrayLength = this.Payagedata.length
      console.log(this.Payagedata)


    });
  }


}
