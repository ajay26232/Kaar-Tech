import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-overallsales',
  templateUrl: './overallsales.component.html',
  styleUrls: ['./overallsales.component.css']
})
export class OverallsalesComponent implements OnInit{
  constructor(private http: HttpClient) { }

  overallSales: any;
  arrayLength:any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }

  ngOnInit(): void {

    this.http.post("http://localhost:3000/overallsales", "{}").subscribe((resp: any) => {

      this.overallSales = resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_OVERALL_SALE_AJAY_FMResponse']['RESULT']['item'];

      this.arrayLength = this.overallSales.length
      console.log(this.overallSales)



    });



  }

}





// this.http.post("http://localhost:3000/inquiry", "{}").subscribe((resp: any) => {

//       this.Inquiries = resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_INQUIRY_NARU_FMResponse']['IT_INQUIRY']['item'];
//       this.arrayLength = this.Inquiries.length

//       console.log(this.Inquiries)


//     });'
// import { HttpClient } from '@angular/common/http';
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-overallsales',
//   templateUrl: './overallsales.component.html',
//   styleUrls: ['./overallsales.component.css']
// })
// export class OverallsalesComponent implements OnInit {

//   constructor(private http:HttpClient) { }

//     overallsales:any;




//     ngOnInit(): void {

//        this.http.post("http://localhost:3000/overallsales","{}").subscribe((resp: any) =>

//        {

//          this.overallsales =resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_OVERALL_SALE_AJAY_FMResponse']['RESULT']['item'];

//         console.log(this.overallsales)


//       });



// }


// }
