import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-financeportal',
  templateUrl: './financeportal.component.html',
  styleUrls: ['./financeportal.component.css']
})
export class FinanceportalComponent {


  private url = 'http://localhost:3000/transactions';

  constructor(private router: Router, private http: HttpClient) {

  }
  invoice() {
    this.router.navigate(['inquirydata']);
  }
  paymentaging() {
    this.router.navigate(['salesorder']);
  }
  creditdebit() {
    
      this.router.navigate(['creditdebit']);

      }
     

  overallsales() {
    this.router.navigate(['overallsales']);
  }

}
