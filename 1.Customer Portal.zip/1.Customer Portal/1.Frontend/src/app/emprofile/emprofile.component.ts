import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-emprofile',
  templateUrl: './emprofile.component.html',
  styleUrls: ['./emprofile.component.css']
})
export class EmprofileComponent {

  constructor(private http: HttpClient) { }

  Profiles: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }

  ngOnInit(): void {

    this.http.post("http://localhost:3000/emprofile", "{}").subscribe((resp: any) => {

      this.Profiles = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZEP_PROFILE_FM_AJAY.Response']['EX_RETURN'];

      console.log(this.Profiles)


    });
  }

}
