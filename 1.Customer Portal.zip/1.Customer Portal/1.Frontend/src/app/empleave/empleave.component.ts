import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-empleave',
  templateUrl: './empleave.component.html',
  styleUrls: ['./empleave.component.css']
})
export class EmpleaveComponent {

  constructor(private http: HttpClient) { }

  leavedatum: any;
  arrayLength: any;
  value: any;
  quotationdata: any;
  searchText: any;
  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }

  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }
  

  ngOnInit(): void {

    this.http.post("http://localhost:3000/empleave", "{}").subscribe((resp: any) => {

      this.leavedatum = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZEP_LEAVE_AJAY_FM.Response']['IT_LEAVE_DATA']['item'];
      this.arrayLength = this.leavedatum.length

      console.log(this.leavedatum)


    });



  }



}
