import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listofdelivery',
  templateUrl: './listofdelivery.component.html',
  styleUrls: ['./listofdelivery.component.css']
})
export class ListofdeliveryComponent implements OnInit {
  constructor(private http:HttpClient) { }

    Lods:any;


    formatDate(dateString: string): string {
      const parts = dateString.split('-');
      const year = parts[0];
      const month = parts[1];
      const day = parts[2];
      return `${day}-${month}-${year}`;
    }
    ngOnInit(): void {

       this.http.post("http://localhost:3000/lod","{}").subscribe((resp: any) =>

       {

         this.Lods =resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_LOD_AJAY_FMResponse']['IT_LOD']['item'];

        console.log(this.Lods)
        this.Lods.shift();


      });



}

}




