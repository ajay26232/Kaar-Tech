import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-vencreditdebit',
  templateUrl: './vencreditdebit.component.html',
  styleUrls: ['./vencreditdebit.component.css']
})
export class VencreditdebitComponent {





  quotationdata: any;
  searchText: any;
  tile: any;
  login: any;

  value = 'Clear me'
  constructor(private http: HttpClient) { }

  Creditdatum: any;
  Debitdatum: any;
  arrayLength: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }

  ngOnInit(): void {

    this.http.post("http://localhost:3000/vencreditdebit", "{}").subscribe((resp: any) => {

      this.Creditdatum = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_CREDIT_DEBIT_AJAY_FM.Response']['IT_CREDIT_MEMO']['item'];
      this.Debitdatum = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_CREDIT_DEBIT_AJAY_FM.Response']['IT_DEBIT_MEMO']['item'];
      this.arrayLength = this.Creditdatum.length
      console.log(this.Creditdatum)
      console.log(this.Debitdatum)




    });
  }


}
