import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-customerportal',
  templateUrl: './customerportal.component.html',
  styleUrls: ['./customerportal.component.css']
})
export class CustomerportalComponent {
  dashboard() {
    this.router.navigate(['./dashboardportal']);
    
  }
  finance() {
    this.router.navigate(['./financeportal']);
    
  }

  profile(){
    this.router.navigate(['./profilepage']);
  }


  constructor(private router: Router, ) {

  }

}
