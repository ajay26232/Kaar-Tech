import { Component } from '@angular/core';

@Component({
  selector: 'app-openingpage',
  templateUrl: './openingpage.component.html',
  styleUrls: ['./openingpage.component.css']
})
export class OpeningpageComponent {

}
