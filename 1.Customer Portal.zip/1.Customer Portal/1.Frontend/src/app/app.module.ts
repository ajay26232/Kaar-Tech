import { BrowserModule } from '@angular/platform-browser';import { NgModule,CUSTOM_ELEMENTS_SCHEMA ,NO_ERRORS_SCHEMA} from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { LoginComponent } from './login/login.component';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import { InquirydataComponent } from './inquirydata/inquirydata.component';
import { CustomerportalComponent } from './customerportal/customerportal.component';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { DashboardportalComponent } from './dashboardportal/dashboardportal.component';
import { SalesorderComponent } from './salesorder/salesorder.component';
import { ListofdeliveryComponent } from './listofdelivery/listofdelivery.component';
import { FinanceportalComponent } from './financeportal/financeportal.component';
import { CreditdebitComponent } from './creditdebit/creditdebit.component';
import { ProfilepageComponent } from './profilepage/profilepage.component';
import { OverallsalesComponent } from './overallsales/overallsales.component';
import { InvoiceDetailsComponent } from './invoice/invoice.component';
import { PaymentComponent } from './payment/payment.component';
import { VenloginComponent } from './venlogin/venlogin.component';
import { OpeningpageComponent } from './openingpage/openingpage.component';
import { VendashboardComponent } from './vendashboard/vendashboard.component';
import { VendorscreenComponent } from './vendorscreen/vendorscreen.component';
import { VendorfinanceComponent } from './vendorfinance/vendorfinance.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { EmpdashboardComponent } from './empdashboard/empdashboard.component';
import { VengoodreceiptComponent } from './vengoodreceipt/vengoodreceipt.component';
import { VencreditdebitComponent } from './vencreditdebit/vencreditdebit.component';
import { VenprofileComponent } from './venprofile/venprofile.component';
import { VenRequotationComponent } from './ven-requotation/ven-requotation.component';
import { VenpurchaseorderComponent } from './venpurchaseorder/venpurchaseorder.component';
import { VenpaymentagingComponent } from './venpaymentaging/venpaymentaging.component';
import { VeninvoiceComponent } from './veninvoice/veninvoice.component';
import { EmprofileComponent } from './emprofile/emprofile.component';
import { EmpleaveComponent } from './empleave/empleave.component';
import { EmpayslipComponent } from './empayslip/empayslip.component';
import { CustdashboardComponent } from './custdashboard/custdashboard.component';


@NgModule({
  declarations: [
    AppComponent, LoginComponent, InquirydataComponent, CustomerportalComponent, DashboardportalComponent, SalesorderComponent, ListofdeliveryComponent, FinanceportalComponent, CreditdebitComponent, ProfilepageComponent, OverallsalesComponent, InvoiceDetailsComponent, PaymentComponent, VenloginComponent, OpeningpageComponent, VendashboardComponent, VendorscreenComponent, VendorfinanceComponent, EmploginComponent, EmpdashboardComponent, VengoodreceiptComponent, VencreditdebitComponent, VenprofileComponent, VenRequotationComponent, VenpurchaseorderComponent, VenpaymentagingComponent, VeninvoiceComponent, EmprofileComponent, EmpleaveComponent, EmpayslipComponent, CustdashboardComponent,
  ],
  imports: [
    FlexLayoutModule,
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MatButtonModule,
    FormsModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatGridListModule,
    MatCardModule,
    HttpClientModule,
    CommonModule,


  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA,
  ],

  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
