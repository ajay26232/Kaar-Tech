import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inquirydata',
  templateUrl: './inquirydata.component.html',
  styleUrls: ['./inquirydata.component.css']
})
export class InquirydataComponent implements OnInit{


    constructor(private http:HttpClient) { }

    Inquiries:any;

    formatNum(numString: string): string {
      const num = parseInt(numString, 10);
      return `${num}`;
    }
    formatDate(dateString: string): string {
      const parts = dateString.split('-');
      const year = parts[0];
      const month = parts[1];
      const day = parts[2];
      return `${day}-${month}-${year}`;
    }

    ngOnInit(): void {

       this.http.post("http://localhost:3000/inquirydata","{}").subscribe((resp: any) =>

       {

         this.Inquiries =resp['soap-env:Envelope']['soap-env:Body']['n0:ZCP_INQUIRY_BAJAY_FMResponse']['IT_INQUIRY']['item'];

        console.log(this.Inquiries)


      });



}

}
