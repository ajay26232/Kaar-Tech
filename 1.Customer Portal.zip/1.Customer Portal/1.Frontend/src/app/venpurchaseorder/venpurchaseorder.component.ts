import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-venpurchaseorder',
  templateUrl: './venpurchaseorder.component.html',
  styleUrls: ['./venpurchaseorder.component.css']
})
export class VenpurchaseorderComponent {

  tile: any;
  login: any;
  searchText: any;
  value = 'Clear me'
  quotationdata: any;

  constructor(private http: HttpClient) { }

  purchasedata: any;
  arrayLength: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }
  ngOnInit(): void {

    this.http.post("http://localhost:3000/venpurchase", "{}").subscribe((resp: any) => {

      this.purchasedata = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_PURCHASE_ORD_AJAY_FM.Response']['IT_PURCHASE_ORDER_HEADER']['item'];
      this.arrayLength = this.purchasedata.length
      console.log(this.purchasedata)
      this.purchasedata.shift();


    });
  }


}
