import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-vengoodreceipt',
  templateUrl: './vengoodreceipt.component.html',
  styleUrls: ['./vengoodreceipt.component.css']
})
export class VengoodreceiptComponent {

  tile: any;
  value: any;
  quotationdata: any;
  searchText: any;

  constructor(private http: HttpClient) { }

  Goodsreceipt : any;
  arrayLength: any;

  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  formatDate(dateString: string): string {
    const parts = dateString.split('-');
    const year = parts[0];
    const month = parts[1];
    const day = parts[2];
    return `${day}-${month}-${year}`;
  }
  ngOnInit(): void {

    this.http.post("http://localhost:3000/venreceipt", "{}").subscribe((resp: any) => {

      this.Goodsreceipt = resp['SOAP:Envelope']['SOAP:Body']['ns0:ZVP_GOODSRECEIPT_AJAY_FM.Response']['IT_GOODS_HEADER']['item'];
      this.arrayLength = this.Goodsreceipt.length
      console.log(this.Goodsreceipt)


    });
  }

}
