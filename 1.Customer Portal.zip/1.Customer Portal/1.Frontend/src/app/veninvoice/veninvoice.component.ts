import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-veninvoice',
  templateUrl: './veninvoice.component.html',
  styleUrls: ['./veninvoice.component.css']
})
export class VeninvoiceComponent {

  searchText: string = '';
  Invoicedata: any;
  arrayLength: any;
  constructor(private http: HttpClient) { }



  formatNum(numString: string): string {
    const num = parseInt(numString, 10);
    return `${num}`;
  }
  pdf:any;




  ngOnInit(): void {

    this.fetchInvoiceeData();
  }

  fetchInvoiceeData(): void {

    this.http.post("http://localhost:3000/veninvoice", "{}").subscribe((resp: any) => {

      this.Invoicedata = resp['SOAP:Envelope']['SOAP:Body']['ns0:Z_VENDOR_INVOICE_AJAY.Response']['IT_INVOICE']['item'];
      this.arrayLength = this.Invoicedata.length
      console.log(this.Invoicedata)
      this.Invoicedata.shift();


    });
  }
  INVOICE_FORM(): void {
    this.http.post("http://localhost:3000/veninvoicepdf", "{}").subscribe((resp: any) => {

    console.log(resp)
    const linkSource = 'data:application/pdf;base64,' + resp;

    const downloadLink = document.createElement('a');

    var filename = 'Vendor' + '-' + 'Invoice';

    downloadLink.href = linkSource;

    downloadLink.download = filename;

    downloadLink.click();


  }, (error) => { console.log(error) });
  }

  INVOICE_MAIL(): void {
    this.http.post("http://localhost:3000/veninvoicepdf", "{}").subscribe((resp: any) => {

    console.log(resp)
    const byteArray = new Uint8Array(

      atob(resp)

        .split('')

        .map((char) => char.charCodeAt(0))

    );

    const blob = new Blob([byteArray], { type: 'application/pdf' });

    const blobUrl = URL.createObjectURL(blob);

    window.open(`mailto:test@example.com?subject=subject&body=${blobUrl}`);


  }, (error) => { console.log(error) });
  }

  INVOICE_PRINT(): void {
    this.http.post("http://localhost:3000/veninvoicepdf", "{}").subscribe((resp: any) => {

    console.log(resp)
    const byteArray = new Uint8Array(

      atob(resp)

        .split('')

        .map((char) => char.charCodeAt(0))

    );

    const blob = new Blob([byteArray], { type: 'application/pdf' });

    const blobUrl = URL.createObjectURL(blob);

    const iframe: any = document.createElement('iframe');

    iframe.style.display = 'none';

    iframe.src = blobUrl;

    document.body.appendChild(iframe);

    iframe.contentWindow.print();


  }, (error) => { console.log(error) });
  }



  filterData(): any[] {
    if (!this.searchText) {
      return this.  Invoicedata;
      ;
    }
    const search = this.searchText.toLowerCase();
    return this.Invoicedata.filter((Invoicedata: any) => {
      return Object.values(Invoicedata).some((value: any) => {
        if (value && typeof value === 'object' && '_text' in value) {
          return value._text.toLowerCase().includes(search);
        }
        return false;
      });
    });
  }

}


